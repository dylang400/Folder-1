package catdog;

import javax.swing.JFrame;

/**
 *
 * @author Dylan Gordon
 */
public class CatDog {
    public static void main(String[] args) {
        
        
        JFrame frame = new JFrame("Cat Dog");
        frame.setSize(600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
        frame.add(new CatDogFace());
       
        frame.setVisible(true);
       
       
    }
    
}
