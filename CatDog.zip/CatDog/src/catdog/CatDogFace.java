package catdog;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import javax.swing.JComponent;

public class CatDogFace extends JComponent {
    
    @Override
    public void paintComponent (Graphics g) {
        
        Graphics2D g2 = (Graphics2D) g;
        
        RenderingHints rHints = new RenderingHints(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2.addRenderingHints(rHints);

        // Backround
        Rectangle back = new Rectangle (600, 600);
        g2.setColor(Color.RED);
        g2.fill(back);
        
        // Head
        Ellipse2D.Double head = new Ellipse2D.Double(150, 150, 300, 300);
        g2.setColor(Color.ORANGE);
        g2.fill(head);
        
        //ears
        Ellipse2D.Double ear1 = new Ellipse2D.Double(140, 130, 80, 110);
        g2.setColor(Color.ORANGE);
        g2.fill(ear1);
        
        Ellipse2D.Double ear2 = new Ellipse2D.Double(380, 130, 80, 110);
        g2.setColor(Color.ORANGE);
        g2.fill(ear2);
        
        //mouth
        
        Ellipse2D.Double mouth = new Ellipse2D.Double(200, 330, 200, 80);
        g2.setColor(Color.WHITE);
        g2.fill(mouth);
        
        Rectangle cover = new Rectangle(200, 300, 200, 65);
        g2.setColor(Color.ORANGE);
        g2.fill(cover);
        
        //makes the head squarer
        Rectangle blank = new Rectangle(180, 600);
        g2.setColor(Color.red);
        g2.fill(blank);
        
        Rectangle blank2 = new Rectangle(420, 0, 180, 600);
        g2.setColor(Color.red);
        g2.fill(blank2);
        
        // nose
        Ellipse2D.Double nose = new Ellipse2D.Double(260, 270, 90, 50);
        g2.setColor(Color.MAGENTA);
        g2.fill(nose);
        
        Ellipse2D.Double glare = new Ellipse2D.Double(280, 275, 60, 30);
        g2.setColor(Color.WHITE);
        g2.fill(glare);
        
        Ellipse2D.Double eye1 = new Ellipse2D.Double(225, 205, 50, 50);
        g2.setColor(Color.WHITE);
        g2.fill(eye1);
        
        Ellipse2D.Double eye2 = new Ellipse2D.Double(335, 205, 50, 50);
        g2.setColor(Color.WHITE);
        g2.fill(eye2);
        
        Ellipse2D.Double pupil1 = new Ellipse2D.Double(240, 215, 15, 15);
        g2.setColor(Color.BLACK);
        g2.fill(pupil1);
        
        Ellipse2D.Double pupil2 = new Ellipse2D.Double(350, 215, 15, 15);
        g2.setColor(Color.BLACK);
        g2.fill(pupil2);
        
        //Eyebrows
        Rectangle brow1 = new Rectangle(225, 205, 50, 10);
        g2.setColor(Color.darkGray);
        g2.fill(brow1);
        
        Rectangle brow2 = new Rectangle(335, 205, 50, 10);
        g2.setColor(Color.darkGray);
        g2.fill(brow2);
        
        // dots for whiskers
        Ellipse2D.Double dot1 = new Ellipse2D.Double(380, 310, 5, 5);
        g2.setColor(Color.BLACK);
        g2.fill(dot1);
        
        Ellipse2D.Double dot2 = new Ellipse2D.Double(365, 325, 5, 5);
        g2.setColor(Color.BLACK);
        g2.fill(dot2);
        
        Ellipse2D.Double dot3 = new Ellipse2D.Double(365, 300, 5, 5);
        g2.setColor(Color.BLACK);
        g2.fill(dot3);
        
        Ellipse2D.Double dot4 = new Ellipse2D.Double(220, 310, 5, 5);
        g2.setColor(Color.BLACK);
        g2.fill(dot4);
        
        Ellipse2D.Double dot5 = new Ellipse2D.Double(235, 325, 5, 5);
        g2.setColor(Color.BLACK);
        g2.fill(dot5);
        
        Ellipse2D.Double dot6 = new Ellipse2D.Double(235, 300, 5, 5);
        g2.setColor(Color.BLACK);
        g2.fill(dot6);
    }
}
